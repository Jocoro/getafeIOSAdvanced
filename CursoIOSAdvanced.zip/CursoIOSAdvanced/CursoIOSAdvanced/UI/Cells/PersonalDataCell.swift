//
//  PersonalDataCell.swift
//  CursoIOSAdvanced
//
//  Created by Dev2 on 16/10/2019.
//  Copyright © 2019 Dev2. All rights reserved.
//

import UIKit
import Kingfisher

class PersonalDataCell: UITableViewCell {
    
     static let cellIdentifier = String(describing: PersonalDataCell.self)
    static let cellHeight: CGFloat = 160
    
   @IBOutlet weak var viewInCell: UIView!
       @IBOutlet weak var imageInCell: UIImageView!
       @IBOutlet weak var name: UILabel!
       @IBOutlet weak var age: UILabel!
        @IBOutlet weak var birthdate: UILabel!
    @IBOutlet weak var gender: UILabel!
  
     override func prepareForReuse() {
            imageInCell.image = nil
            name.text = nil
            age.text = nil
            birthdate.text = nil
        gender.text = nil
        }
       

    override func awakeFromNib() {
        super.awakeFromNib()
     viewInCell.configureShadows()
     viewInCell.layer.cornerRadius = 8.0
        
    }
    func configureCell(image: String? = nil, name: String? = nil, age: String? = nil, birthdate: Date? = nil, gender: String? = nil){
        let url = URL(string: image ?? "")
        imageInCell.kf.setImage(with: url)
        self.name.text = name
        if let age = age {
            self.age.text = age + " years"}
        //Para transformar la fecha en String
        if let birthdate = birthdate{
                   let formatter = DateFormatter()
                   formatter.dateFormat = "EEEE' The 'dd'th of 'MMMM', 'yyyy"
        self.birthdate.text = "Birthdate: " + formatter.string(from: birthdate)
        }
        self.gender.text = gender
        imageInCell.layer.cornerRadius = imageInCell.frame.height/2
    }
    
    
}
