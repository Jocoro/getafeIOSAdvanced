//
//  StreetDTO.swift
//  CursoIOSAdvanced
//
//  Created by Dev2 on 04/10/2019.
//  Copyright © 2019 Dev2. All rights reserved.
//

import Foundation
struct StreetDTO : Codable{
    let number : Int?
    let name : String?
}
